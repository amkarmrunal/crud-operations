const express = require('express')
const ejs =  require('ejs')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const Employee= require('./model/employee');
//const employeeController = require('./controllers/employeeController')
const app= express()

const port = 5000

app.set ('view engine','ejs')
app.use(bodyParser.urlencoded({extended:true}))


mongoose.connect('mongodb://localhost:27017/employeeDB',{
    useNewUrlParser:true,
    useUnifiedTopology:true
})

app.get('/',async(req,res)=>{
    const employees=await Employee.find()
    res.render('index',{employees})
})

app.post('/save',async(req,res)=>{
    const{name,email,dept,city}=req.body
    const employee = new Employee({name,email,dept,city});
    await employee.save()

    res.redirect('/')
})

app.get('/:id', async (req, res) => {
    try {
        const employeeId = req.params.id;
        if (!mongoose.Types.ObjectId.isValid(employeeId)) {
            return res.status(400).send('Invalid employee ID');
        }
        const employee = await Employee.findById(employeeId);
        if (!employee) {
            return res.status(404).json({ message: 'Employee not found' });
        }
        res.render('update', { employee }); // Pass employee object, not employees array
    } catch (error) {
        console.error('Error fetching employee for editing:', error);
        res.status(500).send('Error fetching employee for editing');
    }
});

app.post('/:id', async (req, res) => {
    try {
        const employeeId = req.params.id;
        const { name, email, dept, city } = req.body;
        await Employee.findByIdAndUpdate(employeeId, { name, email, dept, city });
        res.redirect('/');
    } catch (error) {
        console.error('Error updating employee:', error);
        res.status(500).send('Error updating employee');
    }
});

app.get('/delete/:id', async (req, res) => {
    try {
        const employeeId = req.params.id;
        
        // Check if the provided employee ID is valid
        if (!mongoose.Types.ObjectId.isValid(employeeId)) {
            return res.status(400).send('Invalid employee ID');
        }

        // Find the employee by ID and delete it
        const deletedEmployee = await Employee.findByIdAndDelete(employeeId);

        // If no employee found with the provided ID, return 404 Not Found
        if (!deletedEmployee) {
            return res.status(404).json({ message: 'Employee not found' });
        }

        // Redirect the user back to the home page
        res.redirect('/');
    } catch (error) {
        // Handle any errors that occur during the process
        console.error('Error deleting employee:', error);
        res.status(500).send('Error deleting employee');
    }
});



app.listen(port,()=>{console.log(`Server Created on port No: ${port}`)})
